const { Client, GatewayIntentBits, EmbedBuilder, Partials, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const fs = require('fs');

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildInvites,
    GatewayIntentBits.GuildPresences
  ],
  partials: [Partials.Message, Partials.Channel, Partials.GuildMember, Partials.User]
});

const inviteData = new Map();
const points = fs.existsSync('./invites.json') ? JSON.parse(fs.readFileSync('./invites.json')) : {};
const REWARD_CHANNEL_ID = '1402032244134248559';// روم النقاط
const WIN_ANNOUNCE_CHANNEL_ID = '1402033013168279684';// روم التهنئة
const recipientId = "476177722549207040";// bank

const rewardsNormal = [
   "💰 **5,000 كريدت**",
   "💵 **10,000 كريدت**",
   "💎 **15,000 كريدت**",
   "💰 **20,000 كريدت**",
   "😢 حظ أوفر"
];
const rewardsSuper = [
  "💎 **30,000 كريدت**",
  "💎 **45,000 كريدت**",
  "💎 **75,000 كريدت**",
  "😢 حظ أوفر",
];

client.on('ready', async () => {
  console.log(`✅ Logged in as ${client.user.tag}`);
  for (const guild of client.guilds.cache.values()) {
    const invites = await guild.invites.fetch().catch(() => null);
    if (invites) inviteData.set(guild.id, new Map(invites.map(inv => [inv.code, inv.uses])));
  }
});

client.on('guildMemberAdd', async member => {
  try {
    const oldInvites = inviteData.get(member.guild.id) || new Map();
    const newInvitesFetch = await member.guild.invites.fetch().catch(() => null);
    if (!newInvitesFetch) return;

    const usedInvite = newInvitesFetch.find(inv => (oldInvites.get(inv.code) || 0) < inv.uses);
    inviteData.set(member.guild.id, new Map(newInvitesFetch.map(inv => [inv.code, inv.uses])));

    if (!usedInvite || !usedInvite.inviter) return console.log('❌ ما قدرت أعرف مين جاب العضو');
    if (usedInvite.inviter.id === member.id) return;

    const accountAge = Date.now() - member.user.createdAt.getTime();
    const oneMonth = 30 * 24 * 60 * 60 * 1000;
    const rewardRoom = await member.guild.channels.fetch(REWARD_CHANNEL_ID);

    if (accountAge < oneMonth) {
      const embed = new EmbedBuilder()
        .setColor(0xffcc00)
        .setDescription(`👋 مرحبًا <@${usedInvite.inviter.id}>!\nالعضو <@${member.id}> حسابه جديد، لم تحصل على نقاط.`);
      return rewardRoom.send({ embeds: [embed] });
    }

    if (!points[usedInvite.inviter.id]) points[usedInvite.inviter.id] = 0;
    points[usedInvite.inviter.id]++;
    fs.writeFileSync('./invites.json', JSON.stringify(points, null, 2));

    const embed = new EmbedBuilder()
      .setColor(0x00ff00)
      .setTitle('🔥 تم تسجيل الدعوة!')
      .setDescription(`👋 مرحبًا <@${usedInvite.inviter.id}>! جلبت <@${member.id}>.\nنقاطك الآن: **${points[usedInvite.inviter.id]}**`);
    rewardRoom.send({ embeds: [embed] });
  } catch (error) {
    console.error('خطأ في جلب الدعوات:', error);
  }
});

client.on('messageCreate', async message => {
  if (message.author.bot) return;

  // عرض النقاط
  if (message.content === '+invites') {
    const userPoints = points[message.author.id] || 0;
    const embed = new EmbedBuilder()
      .setColor(0x00AE86)
      .setTitle('📊 نقاط الدعوات')
      .setDescription(`لديك **${userPoints} نقطة دعوة 🔥**`);
    return message.reply({ embeds: [embed] });
  }

  // عجلة الحظ
  if (message.content.startsWith('+spin')) {
    if (!message.channel.name.startsWith('ticket')) return;

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('normal_spin').setLabel('🎡 عجلة عادية (1 نقطة / 7k كريدت)').setStyle(ButtonStyle.Primary),
      new ButtonBuilder().setCustomId('super_spin').setLabel('💎 سوبر عجلة (2 نقاط / 25k كريدت)').setStyle(ButtonStyle.Danger)
    );

    await message.reply({ content: '**اختر نوع العجلة:**', components: [row] });
  }

  // أمر إعادة ضبط النقاط
  if (message.content === '+resetinvites') {
    if (message.author.id !== '476177722549207040') {
      return message.reply('❌ أنت غير مصرح لك باستخدام هذا الأمر.');
    }
    for (const key in points) points[key] = 0;
    fs.writeFileSync('./invites.json', JSON.stringify(points, null, 2));
    const embed = new EmbedBuilder()
      .setColor(0xff0000)
      .setTitle('🔄 تم إعادة ضبط النقاط')
      .setDescription('تم مسح جميع نقاط الدعوات! الجميع بدأ من جديد.');
    return message.channel.send({ embeds: [embed] });
  }
});

// التعامل مع الضغط على الأزرار
client.on('interactionCreate', async interaction => {
  if (!interaction.isButton()) return;
  if (!interaction.channel.name.startsWith('ticket')) return;

  const userId = interaction.user.id;
  const username = interaction.user.username;
  const type = interaction.customId;
  const cost = type === 'super_spin' ? 2 : 1;
  const creditCost = type === 'super_spin' ? 26316 : 7369;
  const rewards = type === 'super_spin' ? rewardsSuper : rewardsNormal;
  const prize = rewards[Math.floor(Math.random() * rewards.length)];
  const channel = interaction.channel; // هنا خزنا القناة

  if ((points[userId] || 0) >= cost) {
    points[userId] -= cost;
    fs.writeFileSync('./invites.json', JSON.stringify(points, null, 2));
    await spinWheel(interaction, prize, channel, userId);
  } else {
    // يطلب تحويل الكريدت
    await interaction.reply({
      content: `❌ لا تمتلك ${cost} نقاط.\nقم بالتحويل للف العجلة:\n\`#credit ${recipientId} ${creditCost}\``,
      ephemeral: true
    });

    // ✅ هنا مكان الكولكتور
    const filter = (m) =>
      m.author.bot &&
      m.content.includes(`has transferred`);

    const collector = channel.createMessageCollector({ filter, time: 60000 });

    collector.on('collect', async () => {
      await spinWheel(interaction, prize, channel, userId);
      collector.stop();
    });
  }
});


async function spinWheel(interaction, prize, channel, userId) {
  let newName = prize.replace(/[^a-zA-Z0-9]/g, '').toLowerCase().slice(0, 10) || 'reward';
  await channel.setName(newName);

  const embed = new EmbedBuilder()
    .setColor(0x00AE86)
    .setTitle('🎉 نتيجة السحب')
    .setDescription(`لقد فزت بـ ${prize} 🎁`);

  try {
    if (!interaction.replied && !interaction.deferred) {
      await interaction.reply({ embeds: [embed] });
    } else {
      await interaction.followUp({ embeds: [embed] });
    }
  } catch (error) {
    console.error('Error replying to interaction:', error);
  }

  const winRoom = await interaction.guild.channels.fetch(WIN_ANNOUNCE_CHANNEL_ID);
  await winRoom.send(`🏆 مبروك <@${userId}>! لقد فزت بـ ${prize}`);
}







client.login('');
